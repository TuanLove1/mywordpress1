// Empty file for registration of translation
