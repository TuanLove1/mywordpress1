<?php
/**
 * Help Panel.
 *
 * @package Blossom_Feminine
 */
?>
<!-- Updates panel -->
<div id="useful-plugins-panel" class="panel-left">
	<h4><?php _e( 'Useful Plugins', 'blossom-feminine' ); ?></h4>

	<p><?php _e( 'Below is a list of useful plugins that will help you get the most out of Blossom Feminine.', 'blossom-feminine' ); ?></p>

	<hr/>

	<ul>
		<li><strong><?php _e( 'HubSpot All-In-One Marketing - Forms, Popups, Live Chat', 'blossom-feminine' ); ?></strong></li>
		<li><strong><?php _e( 'WooCommerce', 'blossom-feminine' ); ?></strong></li>
	</ul>
	

</div><!-- .panel-left -->